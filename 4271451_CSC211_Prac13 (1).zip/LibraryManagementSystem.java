/***
 * Student surname          : Bandarkar
 * Student first name       : Mohamed Asad
 * Student number           : 4271451
 * CSC211 2023 Practical 3
 * File name                : LibraryManagementSystem.java
 */

//Import Java modules and other libraries go here
import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LibraryManagementSystem librarymansys = new LibraryManagementSystem();

        while (true) {                                    //this will be displayed to the terminal continuously
            System.out.println("1. Add Book: ");
            System.out.println("2. Add Book before a specific book ID: ");
            System.out.println("3. Search book by book ID: ");
            System.out.println("4. Delete book by book ID: ");
            System.out.println("5. List all books: ");
            System.out.println("6. Sort library by book ID: ");
            System.out.println("7. Count total books: ");
            System.out.println("0. Exit: ");

            System.out.println("Enter your choice:");
            int num = scanner.nextInt();
            scanner.nextLine();

            switch (num) {                              //methods will be accessed by what number the user inputs to the terminal
                case 1:
                    Book newBook = new Book();
                    librarymansys.insertBook(newBook);
                    break;

                case 2:
                    newBook = new Book();
                    librarymansys.insertBefore(newBook);
                    break;

                case 3:
                    newBook = new Book();
                    librarymansys.searchBook();
                    break;

                case 4:
                    librarymansys.deleteBook();
                    break;

                case 5:
                    librarymansys.listAllBooks();
                    break;

                case 6:
                    librarymansys.sortLibrary();
                    break;

                case 7:
                    librarymansys.totalBooks();
                    break;

                case 0:
                    System.exit(0);
                    default:
                        System.out.println("Invalid choice, please try again.");     //any other number other than 0-7 displays this message
            }
        }
    }

    //List of attributes variables go here
    private Node headNode;
    int num;     //for counter variable


    //List of default constructors
    public LibraryManagementSystem() {
        headNode = null;                               //initialising headnode to null
    }

    private void searchBook() {
    }


    //Question 3.1
    public void insertBook(Book newBook) {
        // Ask the librarian to input all the necessary book information
        System.out.println("Please enter the title of the book: ");
        Scanner scanner = new Scanner(System.in);
        String title = scanner.nextLine();
        System.out.println(title + " has been added to the library.");

        System.out.println("Please enter the author of the book: ");
        String author = scanner.nextLine();

        System.out.println("Please enter the publisher of the book: ");
        String publisher = scanner.nextLine();

        System.out.println("Please enter the Book ID of the book: ");
        int bookID = scanner.nextInt();

        // Creating a book object
        newBook = new Book(title, author, publisher, bookID);

        //Storing the book object into the node object
        Node node = new Node(newBook);

        if (headNode == null) {
            headNode = node; // If the linked list is empty, set the headNode to the new node object
        } else {
            // Traversing the linked list to the last node object
            Node currentNode = headNode;
            while (currentNode.getNextNode() != null) {        //while node is not empty
                currentNode = currentNode.getNextNode();
            }
            // Linking the new node object with the rest of the linked list
            currentNode.setNextNode(node);
        }
    }


    //Question 3.2
    public void insertBefore(Book newBook) {
        System.out.println("Please enter the title of the book");
        Scanner scanner = new Scanner(System.in);
        String title = scanner.nextLine();
        System.out.println(title + "has been added to the library.");

        System.out.println("Please enter the author of the book");
        String author = scanner.nextLine();

        System.out.println("Please enter the publisher of the book");
        String publisher = scanner.nextLine();

        System.out.println("Please enter the Book ID of the book");
        int bookID = scanner.nextInt();

        //creating book object to insert book
        Book insertBook = new Book(title, author, publisher, bookID);

        //Searching for the matching Book Object
        Node currentNode = headNode;
        if (currentNode == null) {
            System.out.println("Book with ID " + bookID + " not found!");    //If the node is empty print out
        } else {
            // Storing the book object into the node object
            Node newNode = new Node(insertBook);

            // Linking the new node object with the rest of the linked list
            newNode.setNextNode(currentNode.getNextNode());
            currentNode.setNextNode(newNode);
        }
    }



    //Question 3.3
    public Book searchBook(int bookID ) {
        Node currentNode = headNode;                                   //the currentNode is the headnode
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the Book ID of the book");
        bookID = scanner.nextInt();

        while (currentNode != null ) {                                 //while node is not empty
            System.out.println("Book with ID " + bookID + " has not been found.");
            break;
        }
        return null;
    }


    //Question 3.4
    public void deleteBook() {
        System.out.println("Enter the BookID which you would like to delete: ");
        Scanner scanner = new Scanner(System.in);
        int bookID = scanner.nextInt();
        if (headNode == null) {
            System.out.println("There are no books in the library.");
        }

        Node currentNode = headNode;
        while (currentNode != null) {
            System.out.println("Book with ID " + bookID + " has not been found.");
        }
    }



    //Question 3.5
    public void listAllBooks() {
        if (headNode == null) {                    //if no books found in the library
            System.out.println("No books found.");
            return;
        }

        Node currentNode = headNode;              //the headNode is the currentNode
        while (currentNode != null) {             //while the currentNode is not empty, get the book in a string representation
            System.out.println(currentNode.getBook().toString());    //list the books
            currentNode = currentNode.getNextNode();
        }
    }

    //Question 3.6
    public void sortLibrary() {
        System.out.println("All books in the library after sorting: ");


    }

    //Question 3.7
    public int totalBooks() {
        int count = 0;                  //counter
        Node currentNode = headNode;   //the headNode is the currentNode
        while (currentNode != null) {
            count++;
            currentNode = currentNode.getNextNode();
        }
        System.out.println("The total number of books in the library is " + count);
        return count;
    }
}    
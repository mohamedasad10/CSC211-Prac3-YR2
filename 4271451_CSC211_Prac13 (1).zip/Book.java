/***
 * Student surname          : Bandarkar
 * Student first name       : Mohamed Asad
 * Student number           : 4271451
 * CSC211 2023 Practical 3
 * File name                : Book.java
 */

public class Book {
    //List of attributes variables go here
    private String title;
    private String author;
    private String publisher;
    private int bookID;


    //List of default constructors
    public Book() {

    }
    public Book( String title,String author, String publisher, int bookID){
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.bookID = bookID;
    }



    //List of accessor methods
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getBookID() {
        return bookID;
    }


    //List of mutator methods
    public void setTitle(String title){
        this.title = title;
    }

    public void setAuthor(String author){
        this.author = author;
    }

    public void setPublisher(String publisher){
        this.publisher = publisher;
    }

    public void setBookID(int bookID){
        this.bookID = bookID;
    }


    //Format your toString
    public String toString() {
        return "Book Title :" + title + ", Author: " + author + ", Publisher: " + publisher + ", BookID: " + bookID;
    }
}
/***
 * Student surname          : Bandarkar
 * Student first name       : Mohamed Asad
 * Student number           : 4271451
 * CSC211 2023 Practical 3
 * File name                : Node.java
 */

public class Node {

    //List of attributes variables here
    private Book book;
    private Node nextNode;

    //List of default constructors
    public Node(Book book) {
        this.book = book;
        nextNode = null;
    }

    //List of accessor methods
    public Book getBook() {
        return book;
    }

    public Node getNextNode() {
        return nextNode;
    }

    //List of mutator methods
    public void setNextNode(Node nextNode){
        this.nextNode = nextNode;
    }

    //Format your toString
    public String toString() {
        //Make use of the Book object
        return "Node book: " + book ;
    }
}